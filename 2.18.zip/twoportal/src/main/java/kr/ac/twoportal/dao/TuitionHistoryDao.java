package kr.ac.twoportal.dao;

public interface TuitionHistoryDao {

}
