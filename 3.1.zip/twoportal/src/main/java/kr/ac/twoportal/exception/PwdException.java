package kr.ac.twoportal.exception;

public class PwdException extends RuntimeException{

	public PwdException(String message) {
		super(message);
	}
}
