package kr.ac.twoportal.service;

import kr.ac.twoportal.dto.LoginInfo;

public interface LoginService {


	LoginInfo getLoginCheck(LoginInfo loginInfo);

}
