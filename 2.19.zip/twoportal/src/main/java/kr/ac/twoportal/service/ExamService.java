package kr.ac.twoportal.service;

public interface ExamService {

}
