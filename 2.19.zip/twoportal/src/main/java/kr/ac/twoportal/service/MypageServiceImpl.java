package kr.ac.twoportal.service;

public class MypageServiceImpl {

}
