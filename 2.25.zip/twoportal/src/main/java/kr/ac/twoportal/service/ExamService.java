package kr.ac.twoportal.service;

import java.util.List;

import kr.ac.twoportal.vo.TestQuestion;

public interface ExamService {

	List<TestQuestion> getTestQuestionsByTestInfoNo(int testInfoNo);
}
