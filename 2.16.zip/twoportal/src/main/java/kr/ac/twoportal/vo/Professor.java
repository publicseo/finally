package kr.ac.twoportal.vo;

import java.util.Date;

import org.apache.ibatis.type.Alias;

@Alias("Professor")
public class Professor {

	private int no;
	private String name;
	private String id;
	private String pwd;
	private String position;
	private Date createDate;
	private String imageName;
	private String backName;
	private String accountNumber;
	private int deptNo;
	private String access;
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public int getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}
	public String getAccess() {
		return access;
	}
	public void setAccess(String access) {
		this.access = access;
	}
	public String getBackName() {
		return backName;
	}
	public void setBackName(String backName) {
		this.backName = backName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	@Override
	public String toString() {
		return "Professor [no=" + no + ", name=" + name + ", id=" + id + ", pwd=" + pwd + ", position=" + position
				+ ", createDate=" + createDate + ", imageName=" + imageName + ", backName=" + backName
				+ ", accountNumber=" + accountNumber + ", deptNo=" + deptNo + ", access=" + access + "]";
	}
	
	
	
}
