package kr.ac.twoportal.service;



import kr.ac.twoportal.vo.Student;


public interface MailService {

	void sendEmail(Student student);
}
