package kr.ac.twoportal.dao;

import java.util.List;
import java.util.Map;

import kr.ac.twoportal.dto.DeptProfessorDto;
import kr.ac.twoportal.vo.Professor;

public interface ProfessorDao {

	 Professor getProFessorById(String id);

	Professor getProFessorByNo(int proNo);

	List<DeptProfessorDto> getProfessors (Map<String, Object> map);
}
