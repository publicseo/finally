package kr.ac.twoportal.service;

public interface ResultService {

}
