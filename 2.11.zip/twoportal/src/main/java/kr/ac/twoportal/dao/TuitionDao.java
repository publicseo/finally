package kr.ac.twoportal.dao;

public interface TuitionDao {

}
