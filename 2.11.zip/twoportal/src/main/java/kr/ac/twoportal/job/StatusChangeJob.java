package kr.ac.twoportal.job;

import java.text.DecimalFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import kr.ac.twoportal.dao.LectureDao;
import kr.ac.twoportal.dto.LectureandCancelDto;

@Component
public class StatusChangeJob {

	@Autowired
	private LectureDao lectureDao;
	
	
	
//	@Scheduled(cron = "0/10 * * * * *")
//	public void execute() {
//		System.out.println("job 실행");
//		
//		Long date = System.currentTimeMillis();
//		System.out.println(date);
//		List<LectureandCancelDto> lectures = lectureDao.getLectureandcancel();
//		
//		System.out.println(lectures);
//		  
//		for (LectureandCancelDto lect : lectures) {
//			
//			DecimalFormat df = new DecimalFormat("#,###");
//			
//			if (lect.getLectStatus().equals("허용") && (Long)lect.getLectCreateDate() >= date) {
//				
//				LectureandCancelDto lecture = lectureDao.getLectureandcancelByLectcancelNo(lect.getCacellNo());
//				lecture.setLectStatus("진행중");
//				lectureDao.updateLecture(lecture.getLectNo());
//			}
//			if (lect.getLectStatus().equals("진행중") && lect.getCalcellStartDate() >= date) {
//				
//				LectureandCancelDto lecture = lectureDao.getLectureandcancelByLectcancelNo(lect.getCacellNo());
//				lecture.setLectStatus("휴강중");
//				lectureDao.updateLecture(lecture.getLectNo());
//			}
//			if (lect.getLectStatus().equals("휴강중") && lect.getCalcellStartDate() >= date) {
//				
//				LectureandCancelDto lecture = lectureDao.getLectureandcancelByLectcancelNo(lect.getCacellNo());
//				lecture.setLectStatus("진행중");
//				lectureDao.updateLecture(lecture.getLectNo());
//			}
//		}
//	}
	
}
