package kr.ac.twoportal.service;

import org.springframework.stereotype.Service;

@Service
public class ResultServiceImpl implements ResultService {

}
