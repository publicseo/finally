package kr.ac.twoportal.dao;

public interface LectureCancelDao {

}
