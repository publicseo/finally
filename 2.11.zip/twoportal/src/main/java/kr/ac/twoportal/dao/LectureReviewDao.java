package kr.ac.twoportal.dao;

public interface LectureReviewDao {

}
