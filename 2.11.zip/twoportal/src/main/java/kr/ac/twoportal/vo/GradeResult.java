package kr.ac.twoportal.vo;

import org.apache.ibatis.type.Alias;

@Alias("GradeResult")
public class GradeResult {

	private int no;
	private int lectureListNo;
	private int score;
	private String rating;
	private int rank;
	private double finalScore;
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public int getLectureListNo() {
		return lectureListNo;
	}
	public void setLectureListNo(int lectureListNo) {
		this.lectureListNo = lectureListNo;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public double getFinalScore() {
		return finalScore;
	}
	public void setFinalScore(double finalScore) {
		this.finalScore = finalScore;
	}
	@Override
	public String toString() {
		return "GradeResult [no=" + no + ", lectureListNo=" + lectureListNo + ", score=" + score + ", rating=" + rating
				+ ", rank=" + rank + ", finalScore=" + finalScore + "]";
	}
	
	
}
