package kr.ac.twoportal.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	@GetMapping("/home.hta")
	public String home() {
		return "home";
	}
	
	
	// 교수로 로그인했을 때 첫 화면
	@GetMapping("/professor/home.hta")
	public String professorHome() {
		return "professor/home";
	}
	
	// 학생으로 로그인했을 때 첫 화면
	@GetMapping("/student/home.hta")
	public String studentHome() {
		return "student/home";
	}
	
	
	
}
