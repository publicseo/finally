package kr.ac.twoportal.dao;

import java.util.List;

import kr.ac.twoportal.vo.LectureDayCheck;

public interface LectureDayCheckDao {

	void insertDayCheck(int no);

	LectureDayCheck getDuplicateCheck(int listNo);

	LectureDayCheck getDayCheckByLecListNo(int listNo);
	LectureDayCheck getDayCheckByLecListNoAndToday(int listNo);
}
