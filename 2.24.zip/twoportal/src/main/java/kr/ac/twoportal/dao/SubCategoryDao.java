package kr.ac.twoportal.dao;

public interface SubCategoryDao {

}
