package kr.ac.twoportal.web.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.mysql.cj.api.Session;

import kr.ac.twoportal.dto.LoginInfo;
import kr.ac.twoportal.form.BoardListForm;
import kr.ac.twoportal.service.BoardService;
import kr.ac.twoportal.vo.Board;
import kr.ac.twoportal.vo.BoardReplie;
import kr.ac.twoportal.vo.Criteria;
import kr.ac.twoportal.vo.PageMaker;


@Controller
public class BoardController {
	
	@Autowired
	private BoardService boardService;
	
	@GetMapping("/staff/boardList.hta")
    public String openBoardList() throws Exception {
        return "/staff/board/boardList";	
	}
	
	@GetMapping("/staff/boardLists.hta")
	@ResponseBody
	public Map<String, Object> openBoardList(BoardListForm boardListform) throws Exception{
		
		System.out.println(boardListform);
		
		Criteria criteria = new Criteria();
		criteria.setPage(boardListform.getPage());
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		map.put("category",boardListform.getCategory()); 	
		map.put("dateorview",boardListform.getDateorview()); 	
		map.put("searchBox",boardListform.getSearchBox()); 	
		map.put("searchOption",boardListform.getSearchOption()); 	
		map.put("pageStart",(boardListform.getPage()-1)*5);
		map.put("perPageNum",criteria.getPerPageNum());
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(criteria);
		pageMaker.setTotalCount(boardService.countBoardListTotal(map));
		

		Map<String, Object> result = new HashMap<String, Object>();
		List<Board> list = boardService.selectBoardList(map);
		result.put("list", list);
		result.put("page",pageMaker);
		System.out.println(result);
		return result;
	}
	
	@RequestMapping(value="/staff/boardDetail.hta")
	public ModelAndView boardDetail(@RequestParam("detail") int boardNo) throws Exception{
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/staff/board/boardDetail");
		
		Board detail = boardService.boardListDetail(boardNo);
		mav.addObject("detail",detail);
		
		return mav;
	}
	
	
	@GetMapping("/staff/selectBoardListReply.hta")
	@ResponseBody
	public List<BoardReplie> getBoardRelpy(@RequestParam("boardNo") int boardNo)throws Exception {
		List<BoardReplie> replies = boardService.getBoardReplies(boardNo);
		return replies;
	}
	
	@PostMapping("/staff/addBoardListReply.hta")
	@ResponseBody
	public List<BoardReplie> addBoardRelpy (BoardReplie boardReplie)throws Exception {
		System.out.println(boardReplie);
		boardService.insertBoardReply(boardReplie);
		
		List<BoardReplie> replies = boardService.getBoardReplies(boardReplie.getBoardNo());
		return replies;
	}
	
	@PostMapping("/staff/updateBoardListReply.hta")
	@ResponseBody
	public String updateBoardRelpy(@RequestParam(value="boardPassword",required=false) String pwd)throws Exception {
		System.out.println(pwd);
		//boardService.updateBoardReply(boardReplie);
		
		//List<BoardReplie> replies = boardService.getBoardReplies(boardReplie.getNo());
		//return replies;
		return null;
	}
	
	@PostMapping("/staff/deleteBoardListReply.hta")
	@ResponseBody
	public List<BoardReplie> deleteBoardRelpy(@RequestParam("password")String password,
											int boardNo)throws Exception {
		boardService.deleteBoardReply(password);
		
		List<BoardReplie> replies = boardService.getBoardReplies(boardNo);
		return replies;
	}
	
	
}
