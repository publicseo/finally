package kr.ac.twoportal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.twoportal.dao.LectureCancelDao;
import kr.ac.twoportal.dto.LectureandCancelDto;

@Service
public class LectureCancelServiceImpl implements LectureCancelService {
	
	@Autowired
	private LectureCancelDao lectureCancelDao;

	@Override
	public List<LectureandCancelDto> getLectureCancelByProNo(int proNo) {
		return lectureCancelDao.getLectureCancelByProNo(proNo);
	}
	
	
	
		
	
	
	
}
