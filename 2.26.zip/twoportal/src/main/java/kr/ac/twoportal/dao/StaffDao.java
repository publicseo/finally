package kr.ac.twoportal.dao;

import kr.ac.twoportal.vo.Staff;

public interface StaffDao {

	Staff getStaffById(String id);
	
}

